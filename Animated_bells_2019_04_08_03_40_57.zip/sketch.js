var x = 0;
var y = 0;
var rot = 0;
var dif = 2;
var backx = -520;
var backy = -260;

var desx = Math.floor((Math.random() * 900) + 50);
var rotvel = 0;
var desy = Math.floor((Math.random() * 450) + 25);
var potrotvel = (Math.random() / 2);
var xvel = Math.floor(Math.random() * 6) * (dif);
var yvel = Math.floor(Math.random() * 6) * (dif);
var score = 0;
var fuel = 100;
var fueluse = 0.1;

let img;
function preload() {
  img = loadImage('space.png');
  img2 = loadImage('stars.png');
  par1 = loadImage('1.png');
  par2 = loadImage('2.png');
  cross = loadImage('cross.png');
}




function setup() {
  createCanvas(1000, 500, WEBGL);
  
  rotvel = potrotvel
}

function draw() {
  
  background(100);
  
  

  
  //background
texture(img2);
  rect(backx,backy,1020,520);
  
  //target
  texture(cross);
    rect(desx - 500, desy - 250, 30, 30)
  
  
  
translate (x,y)
   rotate(rot);
   texture(img);
rect(-15, -15, 30, 30)

  
   backx = -510;
 backy = -255;
  
  
  
  
  
   backx += (Math.random() * 6) * (2);
 backy += (Math.random() * 6) * (2);
  if (fuel > 0) {
  if (keyIsDown(87)) {
       yvel -=0.3
    fuel -= fueluse
  }
   if (keyIsDown(83)) {
       yvel += 0.3
     fuel -= fueluse
  }
   if (keyIsDown(65)) {
       xvel -= 0.3
     fuel -= fueluse
  }
   if (keyIsDown(68)) {
       xvel += 0.3
     fuel -= fueluse
  }
   if (keyIsDown(81)) {
       rotvel -= 0.001
     fuel -= fueluse
  }
   if (keyIsDown(69)) {
       rotvel += 0.001
     fuel -= fueluse
  }
  }
 if ((y + 250) < (desy + 20)){
   if ((y + 250) > (desy - 20)){
     if ((x + 500) < (desx + 20)){
       if ((x + 500) > (desx - 20)){
         if (xvel < (1)){
           if (yvel < (1)){
             if (yvel > (-1)){
               if (xvel > (-1)){
                 if (rotvel < (0.03)){
                   if (rotvel > (-0.03)){
             
         score += 2;
      if (score > 100) {
       print ("win")
        fuel = 100
        desy = Math.floor((Math.random() * 450) + 25);
        desx = Math.floor((Math.random() * 900) + 50);
      }
       }}}}}}}}}}
  if (score > 0){
  score -= 1;
  }
  x += xvel;
  y += yvel;
  rot += rotvel;

  //print('dex' + desx);
  //print('dey' + desy);
  //print('x' + (x+500));
  //print('y' + (y+250));
  //print('yvel' + (yvel));
  //print('rotvel' + (rotvel));
  //print('frame' + 1);
  print(score)
  print(fuel)

  
   
}